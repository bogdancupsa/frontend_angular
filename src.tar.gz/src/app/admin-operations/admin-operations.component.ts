import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service'; // Adjust the path based on your folder structure

@Component({
  selector: 'app-admin-operations',
  templateUrl: './admin-operations.component.html',
  styleUrls: ['./admin-operations.component.css']
})
export class AdminOperationsComponent implements OnInit {
  clients: any[] = [];

  constructor(private userService: UserService) { }

  ngOnInit() {
    // Call your UserService method to get clients
    this.userService.getClients().subscribe(
      response => {
        this.clients = response;
      },
      error => {
        console.error('Failed to fetch clients', error);
        // Handle error, show a message, etc.
      }
    );
  }
}
