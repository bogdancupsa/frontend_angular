import { Component } from '@angular/core';

@Component({
  selector: 'app-client-operations',
  templateUrl: './client-operations.component.html',
  styleUrls: ['./client-operations.component.css']
})
export class ClientOperationsComponent {

}
